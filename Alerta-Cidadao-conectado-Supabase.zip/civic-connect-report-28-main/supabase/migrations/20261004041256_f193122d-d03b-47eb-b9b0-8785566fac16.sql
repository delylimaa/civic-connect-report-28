-- Evolui o modelo de ocorrências para categorias/subcategorias sem deixar
-- o CHECK legado bloquear a migração dos registros existentes.
ALTER TABLE public.ocorrencias
  DROP CONSTRAINT IF EXISTS ocorrencias_categoria_check;

ALTER TABLE public.ocorrencias
  ADD COLUMN IF NOT EXISTS subcategoria text,
  ADD COLUMN IF NOT EXISTS secretaria text;

UPDATE public.ocorrencias
SET subcategoria = categoria,
    categoria = 'infraestrutura',
    secretaria = 'obras'
WHERE categoria IN ('buraco_via', 'iluminacao_publica');

UPDATE public.ocorrencias
SET subcategoria = 'lixo',
    categoria = 'meio_ambiente',
    secretaria = 'meio_ambiente'
WHERE categoria = 'lixo';

UPDATE public.ocorrencias
SET subcategoria = 'outro',
    secretaria = 'ouvidoria'
WHERE categoria = 'outros';

ALTER TABLE public.ocorrencias
  ADD CONSTRAINT ocorrencias_categoria_check
  CHECK (
    categoria IN (
      'infraestrutura',
      'saneamento',
      'mobilidade',
      'meio_ambiente',
      'ordem_publica',
      'acessibilidade',
      'outros'
    )
  );
