import logo from "@/assets/logo-alerta-cidadao.png";
import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <img
      src={logo}
      alt="Alerta Cidadão — Sua voz tem poder"
      className={cn("h-auto w-auto object-contain", className)}
      decoding="async"
    />
  );
}
