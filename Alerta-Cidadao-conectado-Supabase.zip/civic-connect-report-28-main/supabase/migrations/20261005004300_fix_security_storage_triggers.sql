-- Corrige dois problemas de produção:
-- 1) o cadastro público não pode conceder perfil de gestor;
-- 2) INSERT em ocorrencias não deve criar duas linhas no histórico;
-- 3) o bucket usado pelo app precisa existir e suas fotos devem respeitar RLS.

ALTER TABLE public.ocorrencias
  ADD COLUMN IF NOT EXISTS subcategoria text,
  ADD COLUMN IF NOT EXISTS secretaria text;

ALTER TABLE public.ocorrencias
  DROP CONSTRAINT IF EXISTS ocorrencias_categoria_check;

UPDATE public.ocorrencias
SET subcategoria = categoria, categoria = 'infraestrutura', secretaria = 'obras'
WHERE categoria IN ('buraco_via', 'iluminacao_publica');

UPDATE public.ocorrencias
SET subcategoria = 'lixo', categoria = 'meio_ambiente', secretaria = 'meio_ambiente'
WHERE categoria = 'lixo';

UPDATE public.ocorrencias
SET subcategoria = 'outro', secretaria = 'ouvidoria'
WHERE categoria = 'outros' AND subcategoria IS NULL;

ALTER TABLE public.ocorrencias
  ADD CONSTRAINT ocorrencias_categoria_check
  CHECK (
    categoria IN (
      'infraestrutura',
      'saneamento',
      'mobilidade',
      'meio_ambiente',
      'ordem_publica',
      'acessibilidade',
      'outros'
    )
  );

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, nome, perfil)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'nome', split_part(NEW.email, '@', 1)),
    'cidadao'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS ocorrencias_status_insert ON public.ocorrencias;

INSERT INTO storage.buckets (id, name, public)
VALUES ('ocorrencias', 'ocorrencias', false)
ON CONFLICT (id) DO UPDATE SET public = false;

DROP POLICY IF EXISTS "fotos_read_auth" ON storage.objects;
CREATE POLICY "fotos_read_auth" ON storage.objects
FOR SELECT TO authenticated
USING (
  bucket_id = 'ocorrencias'
  AND (
    (storage.foldername(name))[1] = auth.uid()::text
    OR public.is_gestor(auth.uid())
  )
);

DROP POLICY IF EXISTS "fotos_insert_own" ON storage.objects;
CREATE POLICY "fotos_insert_own" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'ocorrencias'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

DROP POLICY IF EXISTS "fotos_delete_own" ON storage.objects;
CREATE POLICY "fotos_delete_own" ON storage.objects
FOR DELETE TO authenticated
USING (
  bucket_id = 'ocorrencias'
  AND (
    (storage.foldername(name))[1] = auth.uid()::text
    OR public.is_gestor(auth.uid())
  )
);
